rouh ( روح ) is a creative wordpress theme for personal blogs, it comes with stylish and elegant design

theme documentation: https://github.com/brahimi-mustapha/rouh-documentation/blob/main/README.md

# assets licenses

icons 
    
    [fontawesome]

    assets/dist/img/arrow-right-solid.svg
    assets/dist/img/caret-down-solid.svg
    assets/dist/img/quote-right-solid.svg

    https://fontawesome.com/
    license: https://fontawesome.com/license/free


    [ owned by the theme author ]

    assets\src\img\cloud1.svg
    assets\src\img\cloud2.svg
    assets\src\img\moon.svg
    assets\src\img\sun.svg
    assets\dist\img\saw-tooth-wave.svg
    assets\dist\img\wave.svg

   [ footer instagram icon ]

   created and owned by the theme author

   [ fonts ]
   
   all the fonts used are provided by google fonts 

   https://fonts.google.com/

   [ tgm ]
	
    license: http://tgmpluginactivation.com/


   [ animejs : javascript animation library ]

    license: https://github.com/juliangarnier/anime/blob/master/LICENSE.md

   [ kirki customizer framework ]

   https://kirki.org/
   license: https://github.com/kirki-framework/kirki/blob/master/LICENSE

   [ autoprefixer ]
   https://www.npmjs.com/package/html-css-autoprefixer

   [ @babel/core @babel/preset-env babel-loader ]
   https://babeljs.io/
   license: https://github.com/dbergey/babeljs/blob/master/LICENSE

   [postcss] 
   license : https://github.com/postcss/postcss/blob/main/LICENSE

   [postcss-cli]
   license: https://github.com/postcss/postcss-cli/blob/master/LICENSE

   [cssnano]
   license: https://github.com/cssnano/cssnano/blob/master/LICENSE-MIT

   [postcss-color-mod-function]
   license: https://www.npmjs.com/package/postcss-color-mod-function   

   [postcss-conditionals]
   license: https://www.npmjs.com/package/postcss-conditionals

   [postcss-conditionals]
   license: https://www.npmjs.com/package/postcss-conditionals

   [postcss-easings]
   license: https://github.com/postcss/postcss-easings/blob/main/LICENSE

   [postcss-import]
   license: https://github.com/postcss/postcss-import/blob/master/LICENSE

   [postcss-import]
   license: https://github.com/postcss/postcss-import/blob/master/LICENSE

   [postcss-nested]
   license: https://github.com/postcss/postcss-nested/blob/main/LICENSE

   [postcss-preset-env]
   license: https://github.com/csstools/postcss-preset-env/blob/main/LICENSE.md

   [postcss-random]
   license: https://github.com/git-slim/postcss-random/blob/master/LICENSE

   [postcss-inline-svg]
   license: https://github.com/TrySound/postcss-inline-svg/blob/master/LICENSE

   [webpack]
   license: https://github.com/webpack/webpack/blob/main/LICENSE

   [webpack-cli]
   license: https://github.com/webpack/webpack-cli/blob/master/LICENSE