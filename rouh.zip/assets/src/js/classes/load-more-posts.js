
class loadMore {

    constructor( element ) {

        console.log( element.data() );

    }

}

export default loadMore;