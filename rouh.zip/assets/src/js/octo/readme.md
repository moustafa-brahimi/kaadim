# welcome to Octo instagram Icon 
Not to much to say include the project and add this to your html and see the magic
`<i class="octo octo-instagram-icon" size="500"></i>`
