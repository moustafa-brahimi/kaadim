import "./css/style.css"
import InstagramIcon from "./icons/instagram-icon";


export default { InstagramIcon };